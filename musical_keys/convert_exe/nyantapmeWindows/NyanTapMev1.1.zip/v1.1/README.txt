This is my first version of NyanTapMe,
so there would be some bugs in the code,
but it is now playable,
in the meantime,
I'll do some updates to remove these bugs..


But, if you find another bug, please do not hesitate to contact me @ mzulfiqar.wardi@gmail.com

follow me @ github.com/yunaranyancat
